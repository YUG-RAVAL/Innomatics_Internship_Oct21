a = set ()
for _ in range(int(input())):
    a.add(input())
print(str(len(a)))