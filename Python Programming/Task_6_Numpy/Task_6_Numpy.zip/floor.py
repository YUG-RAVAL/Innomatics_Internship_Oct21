import numpy as np
np.set_printoptions(sign=' ')
x = np.array(input().split(),float)
print(np.floor(x))
print(np.ceil(x))
print(np.rint(x))
