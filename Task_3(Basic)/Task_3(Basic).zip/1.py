import cmath
print(*cmath.polar(complex(input())), sep='\n')