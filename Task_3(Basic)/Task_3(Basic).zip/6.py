a = int(input())
b = int(input())
c = int(input())
d = int(input())
s = 0
s = (a**b) + (c**d)
print(s)