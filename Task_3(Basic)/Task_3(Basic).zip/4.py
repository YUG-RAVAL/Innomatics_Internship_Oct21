a = int(input())
b = int(input())
d = a//b
m = a%b
print(d)
print(m)
print("("+str(d)+", "+str(m)+")")