def swap_case(s):
    a = s.swapcase()
    return a