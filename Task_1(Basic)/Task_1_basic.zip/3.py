if __name__ == '__main__':
    a = int(input())
    b = int(input())
    s = a + b
    s1 = a - b
    p = a * b 
    print(s)
    print(s1)
    print(p) 